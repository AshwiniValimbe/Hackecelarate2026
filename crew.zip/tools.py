"""CrewAI tool wrappers around the deterministic scoring/ticketing logic.

Neither tool calls an LLM. compute_maintenance_score is the only source of
the numeric score/tier an agent may use; agents are instructed never to
recompute or second-guess it.
"""

import uuid
from datetime import datetime, timezone

from crewai.tools import tool

from scoring import compute_score, load_analyzer_log


@tool("compute_maintenance_score")
def compute_maintenance_score_tool(analyzer_id: str) -> str:
    """Compute the deterministic maintenance score, severity tier, and
    weighted feature breakdown for a lab analyzer from its 90-day event
    log CSV. Input: the analyzer_id (e.g. 'LAB-007'). Returns a JSON
    string with score, tier, features, and patient-safety-floor info.
    This is the only authoritative source of the score — do not
    recompute or second-guess it."""
    df = load_analyzer_log(analyzer_id)
    result = compute_score(analyzer_id, df)
    return result.model_dump_json()


@tool("generate_ticket_id")
def generate_ticket_id_tool(analyzer_id: str) -> str:
    """Generate a deterministic-format mock maintenance escalation ticket
    ID for an analyzer, e.g. 'TCKT-LAB-007-20260712-ab12'. Input: the
    analyzer_id. Use this instead of inventing a ticket ID yourself."""
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d")
    suffix = uuid.uuid4().hex[:4]
    return f"TCKT-{analyzer_id}-{timestamp}-{suffix}"

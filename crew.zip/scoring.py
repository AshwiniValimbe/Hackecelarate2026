"""Deterministic maintenance-score computation for lab analyzer event logs.

No LLM calls happen here. Given a 90-day event log DataFrame, this module
computes six weighted 0-100 features, blends them into a single score, and
applies a patient-safety floor that can force the tier to "Serious"
regardless of the weighted score.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

from models import DiagnosticsOutput

SEVERITY_MAP = {"none": 0, "low": 25, "medium": 50, "high": 75, "critical": 100}
PATIENT_IMPACT_MAP = {
    "None": 0,
    "Delayed Result": 40,
    "Incorrect Result Reported": 75,
    "Injury Risk": 100,
}

WEIGHTS = {
    "patient_impact_severity": 0.25,
    "device_malfunction_severity": 0.25,
    "recurring_device_problem": 0.20,
    "error_frequency": 0.10,
    "trend_slope": 0.10,
    "anomaly_recency": 0.10,
}

TIER_THRESHOLDS = [(80, "Serious"), (60, "Moderate"), (40, "Low"), (0, "Minimal")]

SAMPLE_DATA_DIR = Path(__file__).parent / "sample_data"


def _tier_for_score(score: float) -> str:
    for threshold, tier in TIER_THRESHOLDS:
        if score >= threshold:
            return tier
    return "Minimal"


def _check_safety_floor(df: pd.DataFrame) -> tuple[bool, str | None]:
    injury_rows = df[df["patient_impact"] == "Injury Risk"]
    if not injury_rows.empty:
        row = injury_rows.iloc[0]
        return True, f"{row['event_type']} on {row['timestamp']} reported Injury Risk patient impact"

    incorrect_high = df[
        (df["patient_impact"] == "Incorrect Result Reported")
        & (df["event_severity"].isin(["high", "critical"]))
    ]
    if not incorrect_high.empty:
        row = incorrect_high.iloc[0]
        return True, (
            f"{row['event_type']} on {row['timestamp']} reported an Incorrect Result "
            f"with {row['event_severity']} severity"
        )

    return False, None


def _feature_patient_impact_severity(df: pd.DataFrame) -> float:
    impact_values = df["patient_impact"].map(PATIENT_IMPACT_MAP).fillna(0)
    worst = impact_values.max()
    non_none_count = int((df["patient_impact"] != "None").sum())
    return float(0.7 * worst + 0.3 * min(100, non_none_count * 20))


def _feature_device_malfunction_severity(df: pd.DataFrame) -> float:
    severity_values = df["event_severity"].map(SEVERITY_MAP).fillna(0)
    event_severity_values = severity_values[severity_values > 0]
    mean_of_events = float(event_severity_values.mean()) if not event_severity_values.empty else 0.0
    return float(0.6 * severity_values.max() + 0.4 * mean_of_events)


def _feature_recurring_device_problem(df: pd.DataFrame) -> float:
    codes = df["device_problem_code"].dropna()
    if codes.empty:
        return 0.0
    distinct_codes = codes.nunique()
    max_recurrence = codes.value_counts().max()
    return float(min(100, distinct_codes * 12 + max_recurrence * 6))


def _feature_error_frequency(df: pd.DataFrame) -> float:
    event_days = int((df["event_severity"] != "none").sum())
    return float(min(100, (event_days / 90) * 100))


def _feature_trend_slope(df: pd.DataFrame) -> float:
    recent = df.sort_values("timestamp").tail(60).reset_index(drop=True)
    if len(recent) < 2:
        return 0.0
    daily_severity = recent["event_severity"].map(SEVERITY_MAP).fillna(0).to_numpy()
    x = np.arange(len(daily_severity))
    slope = np.polyfit(x, daily_severity, 1)[0]
    return float(np.clip(slope * 20, 0, 100))


def _feature_anomaly_recency(df: pd.DataFrame) -> float:
    sorted_df = df.sort_values("timestamp")
    notable = sorted_df[
        (sorted_df["event_severity"].isin(["high", "critical"]))
        | (sorted_df["patient_impact"] != "None")
    ]
    if notable.empty:
        return 0.0

    last_notable_date = pd.to_datetime(notable["timestamp"].iloc[-1])
    last_date = pd.to_datetime(sorted_df["timestamp"].iloc[-1])
    days_since = (last_date - last_notable_date).days

    if days_since <= 7:
        return 100.0
    return float(100 * np.exp(-days_since / 14))


def compute_features(df: pd.DataFrame) -> dict[str, float]:
    return {
        "patient_impact_severity": round(_feature_patient_impact_severity(df), 1),
        "device_malfunction_severity": round(_feature_device_malfunction_severity(df), 1),
        "recurring_device_problem": round(_feature_recurring_device_problem(df), 1),
        "error_frequency": round(_feature_error_frequency(df), 1),
        "trend_slope": round(_feature_trend_slope(df), 1),
        "anomaly_recency": round(_feature_anomaly_recency(df), 1),
    }


def compute_score(analyzer_id: str, df: pd.DataFrame) -> DiagnosticsOutput:
    features = compute_features(df)
    weighted_sum = sum(features[name] * weight for name, weight in WEIGHTS.items())
    score = round(float(np.clip(weighted_sum, 0, 100)), 1)
    tier = _tier_for_score(score)

    safety_floor_triggered, safety_floor_reason = _check_safety_floor(df)
    if safety_floor_triggered:
        tier = "Serious"

    return DiagnosticsOutput(
        analyzer_id=analyzer_id,
        score=score,
        tier=tier,
        features=features,
        safety_floor_triggered=safety_floor_triggered,
        safety_floor_reason=safety_floor_reason,
    )


def load_analyzer_log(analyzer_id: str) -> pd.DataFrame:
    csv_path = SAMPLE_DATA_DIR / f"{analyzer_id}.csv"
    # keep_default_na=False prevents pandas from silently reading our literal
    # "None" (patient_impact sentinel) as NaN; na_values=[""] still treats
    # genuinely empty fields (event_type/device_problem_code on no-event
    # days) as NaN so .dropna() continues to work as intended.
    return pd.read_csv(csv_path, keep_default_na=False, na_values=[""])


if __name__ == "__main__":
    registry_path = SAMPLE_DATA_DIR / "analyzer_registry.json"
    if not registry_path.exists():
        raise SystemExit(
            "No sample data found. Run `python data_generator.py` first."
        )

    registry = json.loads(registry_path.read_text())
    print(f"{'analyzer_id':<10} {'type':<22} {'score':>7} {'tier':<10} safety_floor")
    for entry in registry:
        analyzer_id = entry["analyzer_id"]
        df = load_analyzer_log(analyzer_id)
        result = compute_score(analyzer_id, df)
        flag = f"YES ({result.safety_floor_reason})" if result.safety_floor_triggered else "no"
        print(
            f"{analyzer_id:<10} {entry['analyzer_type']:<22} {result.score:>7} "
            f"{result.tier:<10} {flag}"
        )

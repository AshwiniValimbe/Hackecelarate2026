from typing import Literal

from pydantic import BaseModel, Field


class DiagnosticsOutput(BaseModel):
    analyzer_id: str
    score: float
    tier: Literal["Serious", "Moderate", "Low", "Minimal"]
    features: dict[str, float] = Field(
        description="The 6 weighted feature contributions that produced the score"
    )
    safety_floor_triggered: bool = Field(
        description="True if tier was forced to Serious by the patient-safety floor, independent of the weighted score"
    )
    safety_floor_reason: str | None = Field(
        default=None,
        description="If safety_floor_triggered, the specific event that triggered it",
    )


class RecommendedAction(BaseModel):
    action: str = Field(description="Specific next step in plain language")
    urgency: Literal["immediate", "within_7_days", "within_30_days", "monitor_only"]
    rationale: str = Field(description="One sentence tying this action to a specific number or event from the input data")


class MaintenanceExplanation(BaseModel):
    plain_summary: str = Field(description="1-3 sentence plain-language summary for a lab/biomedical-engineering reader")
    key_findings: list[str] = Field(description="Bullet points citing concrete numbers or events from the input features")
    recommended_actions: list[RecommendedAction]
    overall_tone: Literal["reassuring", "cautionary", "urgent"]


class EscalationOutput(BaseModel):
    ticket_id: str
    alert_message: str

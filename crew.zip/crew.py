"""CrewAI crew definition for the Device Pulse Agent.

Sequential crew: Diagnostics Engineer (deterministic score via tool) ->
Escalation Coordinator (ConditionalTask, only runs for Serious tier) ->
Maintenance Communicator (plain-language explanation, aware of any
escalation ticket).

The ConditionalTask's `condition` receives the output of the immediately
preceding task in the tasks list -- which is why Escalation is placed right
after Diagnostics, so `condition` can read `tier` directly.
"""

from __future__ import annotations

import argparse
import json
import os

from dotenv import load_dotenv

load_dotenv()

from crewai import Agent, Crew, LLM, Process, Task
from crewai.tasks.conditional_task import ConditionalTask
from crewai.tasks.task_output import TaskOutput

from models import DiagnosticsOutput, EscalationOutput, MaintenanceExplanation
from tools import compute_maintenance_score_tool, generate_ticket_id_tool

DEFAULT_MODEL = os.environ.get("CREWAI_MODEL", "anthropic/claude-opus-4-8")

DISCLAIMER = (
    "This is a maintenance-triage decision-support tool, not an FDA MAUDE "
    "reportability determination or a clinical/regulatory judgment. Never "
    "assert whether an event 'must be reported' -- only that it warrants "
    "review. Do not speculate about clinical diagnoses or patient outcomes "
    "beyond the structured patient_impact field you are given."
)


def _is_serious(output: TaskOutput) -> bool:
    return bool(output.pydantic and output.pydantic.tier == "Serious")


def build_crew(model: str = DEFAULT_MODEL) -> Crew:
    llm = LLM(model=model)

    diagnostics_agent = Agent(
        role="Diagnostics Engineer",
        goal="Determine the precise maintenance score and severity tier for a lab analyzer from its 90-day event log.",
        backstory=(
            "A biomedical equipment diagnostics specialist who never estimates "
            "a score by eye -- always calls the compute_maintenance_score tool "
            "and reports its result exactly, including whether the "
            "patient-safety floor was triggered."
        ),
        tools=[compute_maintenance_score_tool],
        llm=llm,
        verbose=True,
    )

    escalation_agent = Agent(
        role="Escalation Coordinator",
        goal="For Serious-tier analyzers only, open a mock maintenance ticket and draft an alert for the biomedical engineering team.",
        backstory=(
            "A lab operations coordinator responsible for routing urgent "
            "equipment issues to biomedical engineering, using the "
            "generate_ticket_id tool for every ticket rather than inventing IDs."
        ),
        tools=[generate_ticket_id_tool],
        llm=llm,
        verbose=True,
    )

    communicator_agent = Agent(
        role="Maintenance Communicator",
        goal="Translate a computed maintenance score into a clear, plain-language explanation and next steps for lab and biomedical engineering staff.",
        backstory=(
            "A clinical lab operations specialist who writes concise, "
            "non-alarmist explanations that cite concrete numbers and events, "
            "and never recomputes or second-guesses the diagnostics score. "
            + DISCLAIMER
        ),
        llm=llm,
        verbose=True,
    )

    diagnostics_task = Task(
        description=(
            "Use the compute_maintenance_score tool to compute the maintenance "
            "score, tier, and feature breakdown for analyzer {analyzer_id}. "
            "Return its result exactly -- do not alter the score, tier, or "
            "features, and do not fabricate a safety_floor_reason if none was "
            "returned by the tool."
        ),
        expected_output=(
            "A DiagnosticsOutput object with analyzer_id, score, tier, "
            "features, safety_floor_triggered, and safety_floor_reason."
        ),
        agent=diagnostics_agent,
        output_pydantic=DiagnosticsOutput,
    )

    escalation_task = ConditionalTask(
        description=(
            "Analyzer {analyzer_id} has been classified Serious tier. Use the "
            "generate_ticket_id tool to open a mock maintenance escalation "
            "ticket, then draft a brief alert message for the biomedical "
            "engineering team citing the specific feature or safety-floor "
            "reason that drove the Serious classification."
        ),
        expected_output="An EscalationOutput object with ticket_id and alert_message.",
        agent=escalation_agent,
        context=[diagnostics_task],
        condition=_is_serious,
        output_pydantic=EscalationOutput,
    )

    communication_task = Task(
        description=(
            "Using the diagnostics result for analyzer {analyzer_id} (score, "
            "tier, features, and any safety-floor reason) as context -- and "
            "the escalation ticket if one was created -- write a "
            "plain-language explanation for lab and biomedical engineering "
            "staff. Map the tier to action framing: Serious -> take the "
            "analyzer offline and run manufacturer-specified QC before "
            "resuming patient testing, escalate to biomedical engineering "
            "immediately (reference the ticket ID if one exists); "
            "Moderate -> schedule a biomedical engineering inspection within "
            "7 days, continue routine QC each shift; Low -> monitor, address "
            "at the next routine preventive-maintenance visit; Minimal -> no "
            "action needed. If the safety floor was triggered, state "
            "explicitly that escalation is due to a specific reported "
            "patient-impact event, independent of the overall trend score. "
            "Never recompute the score. " + DISCLAIMER
        ),
        expected_output=(
            "A MaintenanceExplanation object with plain_summary, key_findings, "
            "recommended_actions, and overall_tone."
        ),
        agent=communicator_agent,
        context=[diagnostics_task, escalation_task],
        output_pydantic=MaintenanceExplanation,
    )

    return Crew(
        agents=[diagnostics_agent, escalation_agent, communicator_agent],
        tasks=[diagnostics_task, escalation_task, communication_task],
        process=Process.sequential,
        verbose=True,
    )


def _pydantic_or_none(task: Task) -> dict | None:
    if task.output is not None and task.output.pydantic is not None:
        return task.output.pydantic.model_dump()
    return None


def run_for_analyzer(analyzer_id: str, model: str = DEFAULT_MODEL) -> dict:
    crew = build_crew(model=model)
    crew.kickoff(inputs={"analyzer_id": analyzer_id})

    diagnostics_task, escalation_task, communication_task = crew.tasks
    return {
        "diagnostics": _pydantic_or_none(diagnostics_task),
        "escalation": _pydantic_or_none(escalation_task),
        "explanation": _pydantic_or_none(communication_task),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run the Device Pulse Agent crew for one analyzer.")
    parser.add_argument("--analyzer_id", required=True, help="e.g. LAB-007")
    parser.add_argument(
        "--model", default=DEFAULT_MODEL,
        help="CrewAI/LiteLLM model string, e.g. anthropic/claude-opus-4-8",
    )
    args = parser.parse_args()

    result = run_for_analyzer(args.analyzer_id, model=args.model)
    print("\n=== RESULT ===")
    print(json.dumps(result, indent=2))

"""Streamlit dashboard for the Device Pulse Agent.

Scoring (deterministic, free) is computed directly via scoring.py for every
analyzer so the overview table and gauge are always available. The CrewAI
crew (which makes real Claude API calls) only runs when the user explicitly
requests an explanation, to avoid unnecessary API cost while browsing.
"""

import hashlib
import json
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from crew import DEFAULT_MODEL, run_for_analyzer
from data_generator import generate_all
from scoring import SAMPLE_DATA_DIR, compute_score, load_analyzer_log

st.set_page_config(page_title="Device Pulse Agent", layout="wide")

DISCLAIMER = (
    "This dashboard is a maintenance-triage decision-support demo, not an "
    "FDA MAUDE reportability determination or a clinical/regulatory "
    "judgment. All analyzer data shown is synthetic; no real patient "
    "information (PHI) is used."
)

TIER_COLORS = {
    "Serious": "#d62728",
    "Moderate": "#ff7f0e",
    "Low": "#bcbd22",
    "Minimal": "#2ca02c",
}

MODEL_OPTIONS = [
    "anthropic/claude-opus-4-8",
    "anthropic/claude-sonnet-5",
    "anthropic/claude-haiku-4-5",
]


def _registry_path() -> Path:
    return SAMPLE_DATA_DIR / "analyzer_registry.json"


@st.cache_data
def load_registry(_version: int) -> list[dict]:
    if not _registry_path().exists():
        return []
    return json.loads(_registry_path().read_text())


def _file_hash(analyzer_id: str) -> str:
    path = SAMPLE_DATA_DIR / f"{analyzer_id}.csv"
    if not path.exists():
        return ""
    return hashlib.md5(path.read_bytes()).hexdigest()[:8]


@st.cache_data(show_spinner=False)
def score_for(analyzer_id: str, log_hash: str) -> dict:
    df = load_analyzer_log(analyzer_id)
    return compute_score(analyzer_id, df).model_dump()


def gauge_figure(score: float, tier: str) -> go.Figure:
    fig = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=score,
            title={"text": f"Maintenance Score ({tier})"},
            gauge={
                "axis": {"range": [0, 100]},
                "bar": {"color": TIER_COLORS.get(tier, "#1f77b4")},
                "steps": [
                    {"range": [0, 40], "color": "#eafbea"},
                    {"range": [40, 60], "color": "#fdf6d8"},
                    {"range": [60, 80], "color": "#fde3cf"},
                    {"range": [80, 100], "color": "#fbdada"},
                ],
            },
        )
    )
    fig.update_layout(height=280, margin=dict(l=20, r=20, t=50, b=20))
    return fig


st.title("Device Pulse Agent")
st.caption("Predictive maintenance triage for clinical lab analyzers")
st.warning(DISCLAIMER)

if "registry_version" not in st.session_state:
    st.session_state.registry_version = 0
if "explanation_cache" not in st.session_state:
    st.session_state.explanation_cache = {}

registry = load_registry(st.session_state.registry_version)

with st.sidebar:
    st.header("Controls")
    if st.button("Regenerate sample data"):
        generate_all()
        st.session_state.registry_version += 1
        st.session_state.explanation_cache = {}
        score_for.clear()
        st.rerun()

    model = st.selectbox("Claude model", MODEL_OPTIONS, index=0)

    if not registry:
        st.info("No sample data found. Click 'Regenerate sample data' above to generate it.")
        st.stop()

    analyzer_options = {f"{e['analyzer_id']} - {e['analyzer_type']}": e["analyzer_id"] for e in registry}
    selected_label = st.selectbox("Analyzer", list(analyzer_options.keys()))
    selected_id = analyzer_options[selected_label]

    refresh_clicked = st.button("Refresh explanation (calls Claude)")

log_hash = _file_hash(selected_id)
diagnostics = score_for(selected_id, log_hash)

st.subheader("All analyzers")
overview_rows = [
    {
        "Analyzer": entry["analyzer_id"],
        "Type": entry["analyzer_type"],
        "Score": (d := score_for(entry["analyzer_id"], _file_hash(entry["analyzer_id"])))["score"],
        "Tier": d["tier"],
        "Safety floor": "yes" if d["safety_floor_triggered"] else "",
    }
    for entry in registry
]
st.dataframe(pd.DataFrame(overview_rows), use_container_width=True, hide_index=True)

st.divider()
st.subheader(f"Detail: {selected_id}")

col1, col2 = st.columns([1, 2])
with col1:
    st.plotly_chart(gauge_figure(diagnostics["score"], diagnostics["tier"]), use_container_width=True)
    if diagnostics["safety_floor_triggered"]:
        st.error(f"Safety floor triggered: {diagnostics['safety_floor_reason']}")

with col2:
    st.markdown("**Feature breakdown (weighted contribution — transparency panel)**")
    feat_df = pd.DataFrame(
        [{"Feature": k, "Value (0-100)": v} for k, v in diagnostics["features"].items()]
    )
    st.dataframe(feat_df, use_container_width=True, hide_index=True)

st.divider()
st.subheader("Plain-language explanation (CrewAI: Diagnostics -> Escalation -> Communication)")

cache_key = (selected_id, log_hash, model)
if refresh_clicked:
    with st.spinner("Running the Device Pulse Agent crew..."):
        try:
            st.session_state.explanation_cache[cache_key] = run_for_analyzer(selected_id, model=model)
        except Exception as exc:  # e.g. missing/invalid ANTHROPIC_API_KEY, network error
            st.session_state.explanation_cache.pop(cache_key, None)
            st.error(f"Could not generate an explanation: {exc}")

result = st.session_state.explanation_cache.get(cache_key)
explanation = result.get("explanation") if result else None
escalation = result.get("escalation") if result else None

if explanation is None:
    st.info(
        "Click 'Refresh explanation' in the sidebar to generate the plain-language "
        "explanation via Claude. (Requires ANTHROPIC_API_KEY in .env — the score, "
        "gauge, and feature breakdown above work without it.)"
    )
else:
    tone_prefix = {"reassuring": "[Reassuring]", "cautionary": "[Cautionary]", "urgent": "[Urgent]"}.get(
        explanation["overall_tone"], ""
    )
    st.markdown(f"**{tone_prefix}** {explanation['plain_summary']}")

    st.markdown("**Key findings**")
    for finding in explanation["key_findings"]:
        st.markdown(f"- {finding}")

    st.markdown("**Recommended actions**")
    st.dataframe(pd.DataFrame(explanation["recommended_actions"]), use_container_width=True, hide_index=True)

    if escalation is not None:
        st.error(f"Escalation ticket **{escalation['ticket_id']}** opened.\n\n{escalation['alert_message']}")

with st.expander("Raw 90-day event log"):
    st.dataframe(load_analyzer_log(selected_id), use_container_width=True, hide_index=True)

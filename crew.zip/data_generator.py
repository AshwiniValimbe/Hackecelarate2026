"""Synthetic 90-day event-log generator for clinical lab analyzers.

Generates a MAUDE-inspired event log (event_type, device_problem_code,
event_severity, patient_impact, ...) for 8 analyzers across 4 instrument
types, engineered so two analyzers land in each of the four maintenance-score
tiers (Minimal, Low, Moderate, Serious). All data is synthetic; no real
patient information is used or required.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

SAMPLE_DATA_DIR = Path(__file__).parent / "sample_data"

EVENT_FAMILY_PREFIX = {
    "Calibration Failure": "CAL",
    "Electrical Failure": "ELEC",
    "Reagent/QC Failure": "QC",
    "Software Malfunction": "SW",
    "Mechanical Failure": "MECH",
    "Sensor Drift": "SENS",
}

NARRATIVE_TEMPLATES = {
    "Calibration Failure": "Daily calibration check failed on {analyzer_type}; recalibration required.",
    "Electrical Failure": "Intermittent power fault detected on {analyzer_type} control board.",
    "Reagent/QC Failure": "QC control result out of range on {analyzer_type}; reagent lot flagged.",
    "Software Malfunction": "Instrument software reported an unhandled error during a run cycle.",
    "Mechanical Failure": "Sample probe/pipetting mechanism jammed during specimen aspiration.",
    "Sensor Drift": "Temperature/optical sensor reading drifted outside tolerance band.",
}


def _make_day_row(
    date,
    analyzer_id,
    analyzer_type,
    rng,
    event_type=None,
    severity="none",
    patient_impact="None",
    device_problem_code=None,
):
    test_volume = max(0, int(rng.normal(300, 30)))
    narrative = None
    if event_type is not None:
        narrative = NARRATIVE_TEMPLATES[event_type].format(analyzer_type=analyzer_type)
    return {
        "timestamp": date.strftime("%Y-%m-%d"),
        "analyzer_id": analyzer_id,
        "analyzer_type": analyzer_type,
        "event_type": event_type,
        "device_problem_code": device_problem_code,
        "event_severity": severity,
        "patient_impact": patient_impact,
        "test_volume": test_volume,
        "narrative": narrative,
    }


def _generate_minimal(analyzer_id, analyzer_type, rng, start_date):
    rows = []
    for i in range(90):
        date = start_date + timedelta(days=i)
        if rng.random() < 0.02:
            event_type = rng.choice(["Calibration Failure", "Sensor Drift"])
            prefix = EVENT_FAMILY_PREFIX[event_type]
            code = f"{prefix}-{rng.integers(1, 5):02d}"
            rows.append(
                _make_day_row(
                    date, analyzer_id, analyzer_type, rng,
                    event_type=event_type, severity="low", device_problem_code=code,
                )
            )
        else:
            rows.append(_make_day_row(date, analyzer_id, analyzer_type, rng))
    return rows


def _generate_low_stable(analyzer_id, analyzer_type, rng, start_date):
    rows = []
    recurring_code = f"{EVENT_FAMILY_PREFIX['Calibration Failure']}-03"
    for i in range(90):
        date = start_date + timedelta(days=i)
        if rng.random() < 0.68:
            reuse_code = rng.random() < 0.75
            event_type = "Calibration Failure" if reuse_code else rng.choice(
                ["Calibration Failure", "Sensor Drift"]
            )
            code = (
                recurring_code
                if reuse_code
                else f"{EVENT_FAMILY_PREFIX[event_type]}-{rng.integers(1, 6):02d}"
            )
            severity = rng.choice(["medium", "high"], p=[0.85, 0.15])
            rows.append(
                _make_day_row(
                    date, analyzer_id, analyzer_type, rng,
                    event_type=event_type, severity=severity, device_problem_code=code,
                )
            )
        else:
            rows.append(_make_day_row(date, analyzer_id, analyzer_type, rng))
    return rows


def _generate_moderate_worsening(analyzer_id, analyzer_type, rng, start_date):
    rows = []
    electrical_code = f"{EVENT_FAMILY_PREFIX['Electrical Failure']}-07"
    mechanical_code = f"{EVENT_FAMILY_PREFIX['Mechanical Failure']}-09"
    for i in range(90):
        date = start_date + timedelta(days=i)
        progress = i / 89
        prob = 0.20 + progress * 0.70
        if rng.random() < prob:
            event_type = rng.choice(["Electrical Failure", "Mechanical Failure"], p=[0.6, 0.4])
            if progress < 0.3:
                severity = "medium"
            elif progress < 0.65:
                severity = rng.choice(["medium", "high"], p=[0.2, 0.8])
            else:
                severity = rng.choice(["high", "critical"], p=[0.4, 0.6])
            code = electrical_code if event_type == "Electrical Failure" else mechanical_code
            rows.append(
                _make_day_row(
                    date, analyzer_id, analyzer_type, rng,
                    event_type=event_type, severity=severity, device_problem_code=code,
                )
            )
        else:
            rows.append(_make_day_row(date, analyzer_id, analyzer_type, rng))
    return rows


def _generate_serious_recurring(analyzer_id, analyzer_type, rng, start_date):
    """Quiet for ~10 weeks, then a recurring critical-fault burst in the
    final ~3 weeks -- Serious purely via the weighted formula (no patient
    Injury Risk event, so the safety floor never fires here)."""
    rows = []
    recurring_code = f"{EVENT_FAMILY_PREFIX['Electrical Failure']}-11"
    acute_start = 69  # final 21 days
    for i in range(90):
        date = start_date + timedelta(days=i)
        if i < acute_start:
            rows.append(_make_day_row(date, analyzer_id, analyzer_type, rng))
            continue

        is_last_day = i == 89
        if is_last_day or rng.random() < 0.9:
            if rng.random() < 0.2:
                # A minority of burst days produce an erroneous result --
                # medium severity only, so this never trips the Injury-Risk /
                # Incorrect-Result-at-high-severity safety floor.
                rows.append(
                    _make_day_row(
                        date, analyzer_id, analyzer_type, rng,
                        event_type="Electrical Failure", severity="medium",
                        patient_impact="Incorrect Result Reported",
                        device_problem_code=recurring_code,
                    )
                )
            else:
                patient_impact = rng.choice(["None", "Delayed Result"], p=[0.6, 0.4])
                rows.append(
                    _make_day_row(
                        date, analyzer_id, analyzer_type, rng,
                        event_type="Electrical Failure", severity="critical",
                        patient_impact=patient_impact, device_problem_code=recurring_code,
                    )
                )
        else:
            rows.append(_make_day_row(date, analyzer_id, analyzer_type, rng))
    return rows


def _generate_serious_safety_floor(analyzer_id, analyzer_type, rng, start_date):
    """Otherwise-healthy analyzer with exactly one Injury Risk event.

    Demonstrates the deterministic safety-floor override: the weighted score
    alone would land in Low/Moderate, but a single patient-safety event
    forces the tier to Serious.
    """
    rows = []
    injury_day = 45
    for i in range(90):
        date = start_date + timedelta(days=i)
        if i == injury_day:
            rows.append(
                _make_day_row(
                    date, analyzer_id, analyzer_type, rng,
                    event_type="Reagent/QC Failure", severity="high",
                    patient_impact="Injury Risk",
                    device_problem_code=f"{EVENT_FAMILY_PREFIX['Reagent/QC Failure']}-07",
                )
            )
        elif rng.random() < 0.02:
            rows.append(
                _make_day_row(
                    date, analyzer_id, analyzer_type, rng,
                    event_type="Calibration Failure", severity="low",
                    device_problem_code=f"{EVENT_FAMILY_PREFIX['Calibration Failure']}-01",
                )
            )
        else:
            rows.append(_make_day_row(date, analyzer_id, analyzer_type, rng))
    return rows


PROFILES = {
    "minimal": _generate_minimal,
    "low_stable": _generate_low_stable,
    "moderate_worsening": _generate_moderate_worsening,
    "serious_recurring": _generate_serious_recurring,
    "serious_safety_floor": _generate_serious_safety_floor,
}

ANALYZER_PLAN = [
    ("LAB-001", "Chemistry Analyzer", "minimal"),
    ("LAB-002", "Hematology Analyzer", "minimal"),
    ("LAB-003", "Immunoassay Analyzer", "low_stable"),
    ("LAB-004", "Coagulation Analyzer", "low_stable"),
    ("LAB-005", "Chemistry Analyzer", "moderate_worsening"),
    ("LAB-006", "Hematology Analyzer", "moderate_worsening"),
    ("LAB-007", "Immunoassay Analyzer", "serious_recurring"),
    ("LAB-008", "Coagulation Analyzer", "serious_safety_floor"),
]


def generate_all(output_dir: Path = SAMPLE_DATA_DIR, seed: int = 42) -> list[dict]:
    output_dir.mkdir(parents=True, exist_ok=True)
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=89)

    registry = []
    for idx, (analyzer_id, analyzer_type, profile_name) in enumerate(ANALYZER_PLAN):
        rng = np.random.default_rng(seed + idx)
        rows = PROFILES[profile_name](analyzer_id, analyzer_type, rng, start_date)
        df = pd.DataFrame(rows)
        df.to_csv(output_dir / f"{analyzer_id}.csv", index=False)
        registry.append(
            {
                "analyzer_id": analyzer_id,
                "analyzer_type": analyzer_type,
                "install_date": (start_date - timedelta(days=365)).strftime("%Y-%m-%d"),
                "location": f"Central Lab - Bay {idx + 1}",
            }
        )

    (output_dir / "analyzer_registry.json").write_text(json.dumps(registry, indent=2))
    return registry


if __name__ == "__main__":
    from scoring import compute_score, load_analyzer_log

    registry = generate_all()
    print(f"Generated {len(registry)} synthetic analyzer logs in {SAMPLE_DATA_DIR}\n")
    print(f"{'analyzer_id':<10} {'type':<20} {'profile':<22} {'score':>7} {'tier':<10} safety_floor")
    for entry, (analyzer_id, analyzer_type, profile_name) in zip(registry, ANALYZER_PLAN):
        df = load_analyzer_log(analyzer_id)
        result = compute_score(analyzer_id, df)
        flag = "YES" if result.safety_floor_triggered else "no"
        print(
            f"{analyzer_id:<10} {analyzer_type:<20} {profile_name:<22} "
            f"{result.score:>7} {result.tier:<10} {flag}"
        )
